package com.example.asus.gottawa;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class PlaceAdapter extends ArrayAdapter<Place> {

    private int backgroundColor; //the background color for the list

    //constructor to set up data
    public PlaceAdapter(Activity context, ArrayList<Place> places, int backgroundColor) {
        super(context,0,places);
        this.backgroundColor = backgroundColor;
    }

    //method to set the view
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView==null) { //pass the correct view
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.place_item,parent,false);
        }
        Place currentPlace = getItem(position); //get the current place object

        //set the image
        ImageView image = (ImageView) listItemView.findViewById(R.id.image);
        image.setImageResource(currentPlace.getPicId());

        //set the title
        TextView title = (TextView) listItemView.findViewById(R.id.title);
        title.setText(getContext().getString(currentPlace.getTitleId()));

        //set the price
        TextView price = (TextView) listItemView.findViewById(R.id.price);
        if (currentPlace.isFree()) {
            price.setText(getContext().getString(R.string.free));
        } else {
            String priceText = "~"+getContext().getString(R.string.price)+currentPlace.getPrice()+" + tax"; //concatenate the correct price string to display
            price.setText(priceText);
        }

        //set the short description
        TextView shortDes = (TextView) listItemView.findViewById(R.id.shortDes);
        shortDes.setText(getContext().getString(currentPlace.getShortDesId()));

        //set the backgound color
        LinearLayout linearLayout = (LinearLayout) listItemView.findViewById(R.id.for_background); //find the linear layout to set the background color
        int color = ContextCompat.getColor(getContext(), this.backgroundColor); //get the background int
        linearLayout.setBackgroundColor(color); //set the color

        return listItemView; //return the correct view
    }
}
