package com.example.asus.gottawa;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    /* icon credit:
    <div>Icons made by <a href="https://www.flaticon.com/authors/surang" title="surang">surang</a> from <a href="https://www.flaticon.com/" 			    title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/" 			    title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ViewPager viewPager = (ViewPager) findViewById(R.id.viewpager); //find the viewpager

        //create category adapter object
        CategoryAdapter categoryAdapter = new CategoryAdapter(this, getSupportFragmentManager());
        viewPager.setAdapter(categoryAdapter); //set the adapter

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs); //find the tab
        tabLayout.setupWithViewPager(viewPager); //setup with the view pager

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) { //create the option menu
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id==R.id.action_help){ //user click the help button
            Intent intent = new Intent(MainActivity.this,HelpActivity.class); //create the intent
            startActivity(intent); //start the intent
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
