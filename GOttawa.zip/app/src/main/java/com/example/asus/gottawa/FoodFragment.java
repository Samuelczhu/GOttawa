package com.example.asus.gottawa;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class FoodFragment extends Fragment {


    public FoodFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.place_list, container, false); //inflate the correct view
        final ArrayList<Place> places = new ArrayList<>(); //create an array list to hold data
        //add data
        places.add(new Place(R.string.tim_horton,R.drawable.tim_horton,R.string.tim_horton_shortDes,R.string.tim_horton_longDes,3));
        places.add(new Place(R.string.little_sheep,R.drawable.little_sheep,R.string.little_sheep_shortDes,R.string.little_sheep_longDes,32));
        places.add(new Place(R.string.popeyes,R.drawable.popeyes,R.string.popeyes_shortDes,R.string.popeyes_longDes,12));
        places.add(new Place(R.string.phobogala,R.drawable.pho_bo_ga_la,R.string.phobogala_shortDes,R.string.phobogala_longDes,12));
        places.add(new Place(R.string.mcDonald,R.drawable.mcdonald,R.string.mcDonald_shortDes,R.string.mcDonald_longDes,6));
        places.add(new Place(R.string.da_gu,R.drawable.da_gu,R.string.da_gu_shortDes,R.string.da_gu_longDes,12));
        places.add(new Place(R.string.sushi168,R.drawable.sushi168,R.string.sushi168_shortDes,R.string.sushi168_longDes,37));

        PlaceAdapter placeAdapter = new PlaceAdapter(getActivity(),places,R.color.colorFood); //create a place adapter
        ListView listView = (ListView) rootView.findViewById(R.id.list); //find the list view
        listView.setAdapter(placeAdapter); //set the adapter

        //set on item click listener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Place place = places.get(position); //get the corresponding place
                Intent intent = new Intent(getActivity(),DetailActivity.class); //create the intent
                intent.putExtra("place",place); //put extra
                startActivity(intent); //start the activity
            }
        });

        return rootView; //return the root view
    }

}
