package com.example.asus.gottawa;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class TourFragment extends Fragment {


    public TourFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.place_list,container,false); //set the place list view
        final ArrayList<Place> places = new ArrayList<>(); //create an array list to store place data
        //add place data
        places.add(new Place(R.string.parliament_hill,R.drawable.parliament,R.string.parliament_hill_shortDes,R.string.parliament_hill_longDes));
        places.add(new Place(R.string.gatineau_park,R.drawable.gatineau,R.string.gatineau_park_shortDes,R.string.gatineau_park_longDes));
        places.add(new Place(R.string.rideau_canal,R.drawable.rideau_canal,R.string.rideau_canal_shortDes,R.string.rideau_canal_longDes));
        places.add(new Place(R.string.mooney_bay,R.drawable.mooneysbay,R.string.mooney_bay_shortDes,R.string.mooney_bay_longDes));
        places.add(new Place(R.string.vincent_massey,R.drawable.vincent,R.string.vincent_massey_shortDes,R.string.vincent_massey_longDes));
        places.add(new Place(R.string.ottawaU,R.drawable.ottawa_university,R.string.ottawaU_shortDes,R.string.ottawaU_longDes));
        places.add(new Place(R.string.carletonU,R.drawable.carleton,R.string.carletonU_shortDes,R.string.carletonU_longDes));
        places.add(new Place(R.string.china_town,R.drawable.china_town,R.string.china_town_shortDes,R.string.china_town_longDes));
        places.add(new Place(R.string.science_museum,R.drawable.science_museum,R.string.science_museum_shortDes,R.string.science_museum_longDes));
        places.add(new Place(R.string.national_gallery,R.drawable.art_gallery,R.string.national_gallery_shortDes,R.string.national_gallery_longDes));
        places.add(new Place(R.string.nature_museum,R.drawable.nature_museum,R.string.nature_museum_shortDes,R.string.nature_museum_longDes));

        //find the list view
        ListView listView = (ListView) rootView.findViewById(R.id.list); //find the list view

        //set the place adapter
        PlaceAdapter placeAdapter = new PlaceAdapter(getActivity(),places,R.color.colorTour); //create the place adapter
        listView.setAdapter(placeAdapter); //set the adapter

        //set the onclick method
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Place place = places.get(position); //get the correct place object
                Intent intent = new Intent(getActivity(),DetailActivity.class); //create the intent
                intent.putExtra("place",place); //put extra to send the place object
                startActivity(intent); //start the activity
            }
        });

        return rootView; //return the root view
    }

}
