package com.example.asus.gottawa;

import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URLEncoder;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Intent intent = getIntent(); //get the intent
        final Place place = (Place) intent.getSerializableExtra("place"); //get the correct place

        ImageView imageView = (ImageView) findViewById(R.id.image); //find the image
        imageView.setImageResource(place.getPicId()); //set the image

        TextView title = (TextView) findViewById(R.id.title); //find the title
        title.setText(getString(place.getTitleId())); //set the title

        TextView longDes = (TextView) findViewById(R.id.longDes); //find the long description
        longDes.setText(getString(place.getLongDesId())); //set the long description

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab); //find the floating action button
        fab.setOnClickListener(new View.OnClickListener() { //set the on click listener
            @Override
            public void onClick(View v) {
                try {
                    String query = URLEncoder.encode(getString(place.getTitleId()), "UTF-8");
                    Uri uri = Uri.parse("http://www.google.com/#q="+query); //get the uri
                    Intent i = new Intent(Intent.ACTION_VIEW,uri); //create an implicit intent
                    startActivity(i); //start the intent
                } catch (Exception e) {
                    //tell user fail to search
                    Toast.makeText(DetailActivity.this,getString(R.string.fail_to_search),Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
