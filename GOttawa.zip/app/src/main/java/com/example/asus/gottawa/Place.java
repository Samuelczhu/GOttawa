package com.example.asus.gottawa;

import java.io.Serializable;

//make this class a serializable class
public class Place implements Serializable { //this class hold the basic information of place

    private int titleId; //hold the name id of the place
    private int picId; //hold the picture id of the place
    private int shortDesId; //hold the short description id
    private int longDesId; //hold the long description id
    private double price; //hold the entrance price of the place

    public Place(int titleId, int picId, int shortDesId, int longDesId, double price) { //constructor to set things up
        this.titleId = titleId;
        this.picId = picId;
        this.shortDesId = shortDesId;
        this.longDesId = longDesId;
        this.price = price;
    }

    public Place(int titleId, int picId, int shortDesId, int longDesId) { //constructor for free place
        this.titleId = titleId;
        this.picId = picId;
        this.shortDesId = shortDesId;
        this.longDesId = longDesId;
        this.price = 0; //free place is 0 dollar
    }

    public boolean isFree() { //check whether the place is free
        return this.price==0;
    }

    //getters
    public int getTitleId(){
        return this.titleId;
    }
    public int getPicId(){
        return this.picId;
    }
    public int getShortDesId(){
        return this.shortDesId;
    }
    public int getLongDesId(){
        return this.longDesId;
    }
    public double getPrice() {
        return this.price;
    }
}
