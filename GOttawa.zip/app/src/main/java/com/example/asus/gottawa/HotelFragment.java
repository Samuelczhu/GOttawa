package com.example.asus.gottawa;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class HotelFragment extends Fragment {


    public HotelFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.place_list,container,false); //inflate the root view

        final ArrayList<Place> places = new ArrayList<>(); //create the array list to store data
        //add data
        places.add(new Place(R.string.fairmont,R.drawable.fairmont,R.string.fairmont_shortDes,R.string.fairmont_longDes));
        places.add(new Place(R.string.lord_eldin,R.drawable.lord,R.string.lord_eldin_shortDes,R.string.lord_eldin_longDes));
        places.add(new Place(R.string.marriot,R.drawable.marriot,R.string.marriot_shortDes,R.string.marriot_longDes));
        places.add(new Place(R.string.sheraton,R.drawable.sheraton,R.string.sheraton_shortDes,R.string.sheraton_longDes));

        ListView listView = (ListView) rootView.findViewById(R.id.list); // find the list

        PlaceAdapter placeAdapter = new PlaceAdapter(getActivity(),places,R.color.colorHotel); //create the adapter
        listView.setAdapter(placeAdapter); //set the adapter

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { //set the on click listener
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Place place = places.get(position); //get the place
                Intent intent = new Intent(getActivity(),DetailActivity.class);//create an intent
                intent.putExtra("place",place); //put the place information
                startActivity(intent); //start the intent
            }
        });
        return rootView; //return the root view
    }

}
