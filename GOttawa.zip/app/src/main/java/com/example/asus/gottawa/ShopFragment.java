package com.example.asus.gottawa;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class ShopFragment extends Fragment {


    public ShopFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.place_list,container,false); //get the root view

        final ArrayList<Place> places = new ArrayList<>(); // create an array list to hold data
        //add data
        places.add(new Place(R.string.rideau_center,R.drawable.rideau_center,R.string.rideau_center_shortDes,R.string.rideau_center_longDes));
        places.add(new Place(R.string.walmart,R.drawable.walmart,R.string.walmart_shortDes,R.string.walmart_longDes));
        places.add(new Place(R.string.canadian_tire,R.drawable.canadian_tire,R.string.canadian_tire_shortDes,R.string.canadian_tire_longDes));
        places.add(new Place(R.string.dollarama,R.drawable.dollarama,R.string.dollarama_shortDes,R.string.dollarama_longDes));
        places.add(new Place(R.string.factory_direct,R.drawable.factory_direct,R.string.factory_direct_shortDes,R.string.factory_direct_longDes));
        places.add(new Place(R.string.costco,R.drawable.costco,R.string.costco_shortDes,R.string.costco_longDes));
        places.add(new Place(R.string.TandT,R.drawable.tandt,R.string.TandT_shortDes,R.string.TandT_longDes));

        PlaceAdapter placeAdapter = new PlaceAdapter(getActivity(),places,R.color.colorShop); //create place adapter

        ListView listView = (ListView) rootView.findViewById(R.id.list); //find the list
        listView.setAdapter(placeAdapter); //set the adapter

        //set the on click listener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Place place = places.get(position); //get the place
                Intent intent = new Intent(getActivity(),DetailActivity.class); //create intent
                intent.putExtra("place",place); //put extra
                startActivity(intent); //start the intent
            }
        });

        return rootView; //return the root view
    }

}
